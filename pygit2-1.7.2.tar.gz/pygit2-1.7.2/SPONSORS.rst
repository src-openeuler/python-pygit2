Friends of pygit2:

- `Iterative <https://iterative.ai/>`_
- `Robert Szymczak <https://github.com/m451>`_

Add your name to the list, `become a friend of pygit2 <https://github.com/sponsors/jdavid>`_.

Past sponsors:

- `SourceHut <https://sourcehut.org>`_
